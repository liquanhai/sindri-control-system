#!/bin/sh
ln -s $PWD/libQt5DBus.so libQt5DBus.so.5
ln -s $PWD/libQt5Core.so libQt5Core.so.5
ln -s $PWD/libQt5Gui.so  libQt5Gui.so.5
ln -s $PWD/libQt5Widgets.so libQt5Widgets.so.5
ln -s $PWD/libQt5Xml.so  libQt5Xml.so.5
ln -s $PWD/libQt5Network.so libQt5Network.so.5
